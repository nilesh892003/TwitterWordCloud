package twitterCal;

public class trial {

	public static void main(String[] args){
		String str="I-Event";
		
		String sp[]=str.split();
		
		System.out.println(sp[0]);
	}
}
