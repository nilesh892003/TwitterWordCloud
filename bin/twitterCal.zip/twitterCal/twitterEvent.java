package twitterCal;
import java.io.*;
public class twitterEvent {
	
	public void retrieveData()throws FileNotFoundException,IOException{
		
		
		BufferedReader br = new BufferedReader(new FileReader("C:\Users\Neo1\Desktop\CS 782_twitterData\nilesh_event.txt"));
		    try {
		        StringBuilder sb = new StringBuilder();
		        //String line = br.readLine();
				String line = br.readLine();
		do{
			
				String[] m=line.split("\\:");
			//System.out.println(m[0]);
			//System.out.println(m[1]);
				if(m[0].equals("StudentID") && m[1].equals(Stuid))
				{	studentid=m[1];
					//while(highschoolyear!=null)
					for(int i=0;i<15;i++)
					{
								
					line = br.readLine();
				//	System.out.println(line);
					
					 m=line.split("\\:");
				if(m[0].equals("firstname"))
					fname=m[1];
				//System.out.println(url);
				if(m[0].equals("Lastname"))
					lname=m[1];
				if(m[0].equals("Gender"))
					gender=m[1];
				
				if(m[0].equals("AddressLine1"))
					address1=m[1];
				
				if(m[0].equals("AddressLine2"))
					address2=m[1];
				if(m[0].equals("zip "))
					zip=m[1];
				
				if(m[0].equals("city"))
					city=m[1];
					
				if(m[0].equals("state"))
					state=m[1];	
					
				if(m[0].equals("Contact number"))
					contactno=m[1];	
					
				if(m[0].equals("Email"))
					email=m[1];	
				
				if(m[0].equals("url"))
					url=m[1]+m[2];	
				
				if(m[0].equals("date"))
					date=m[1];	
					
				if(m[0].equals("Comments"))
					comments=m[1];	
					
				if(m[0].equals("highschoolmonth"))
					highschoolmonth=m[1];	
					
				if(m[0].equals("highschoolyear"))
					highschoolyear=m[1];
					
					
					
					
		 //line = br.readLine();
		 }
		 } //if condition ends (studentid check)
		 		
					
		 line = br.readLine();

		}while(line!=null);

		System.out.println(studentid);
		System.out.println(fname+url);
		/*
		        while (line != null) {
				String line = br.readLine();
				
				String[] m=line.split("\\:");
				if(m[0]=="StudentID");
					studentid=m[1];
					
				System.out.println(studentid);
		           // sb.append(line);
		         //   sb.append("\n");
		            //line = br.readLine();
		        }
		        everything = sb.toString();
				//System.out.println(everything);*/
		    } finally {
		        br.close();
		    }
			if(studentid!=null){
		StudentBean sb=new StudentBean(studentid,fname,lname,gender,address1,address2,zip,city,state,contactno,email,url,date,comments,highschoolmonth,highschoolyear);
			return sb;
			}
			
			else
				return null;
			}

}
